document.getElementById('nextBtn').addEventListener('click', function() {
    const emailStep = document.getElementById('email-step');
    const passwordStep = document.getElementById('password-step');

    // Hide email step and show password step
    emailStep.classList.remove('active');
    passwordStep.classList.add('active');
});

document.getElementById('enteredEmail').addEventListener('click', function() {
    const emailStep = document.getElementById('email-step');
    const passwordStep = document.getElementById('password-step');

    // Hide password step and show email step
    passwordStep.classList.remove('active');
    emailStep.classList.add('active');
});

