<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In Error</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #ffffff;
            color: #323130;
        }
        h1 {
            font-size: 40px;
            color: #167ad5;
            margin-bottom: 10px;
            font-weight: normal;
        }
        p {
            font-size: 16px;
            color: #605e5c;
            margin: 5px 0;
            font-weight: normal;
        }
        .p2 {
            font-size: 16px;
            color: #167ad5;
            font-weight: 500;
        }
        .button {
            display: inline-block;
            margin: 20px 0;
            padding: 8px 24px;
            font-size: 16px;
            color: #ffffff;
            background-color: #0078d4;
            text-decoration: none;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        .button:hover {
            background-color: #005a9e;
        }
        .error-details {
            font-size: 12px;
            color: #605e5c;
            font-weight: 300;
            white-space: pre-line;
        }
    </style>
</head>
<body>
    <h1>Something went wrong.</h1>
    <p>Please try again later.</p>
    <a href="https://my.monmouth.edu" class="button">Refresh the page</a>
    <p class="p2">Details<h2>
    <div class="error-details">
    UTC Date: 2024-12-06T08:25:31.112Z  
BootResult: authentication-failure  
Client Id: C48B89DF12E14BB8B234F2C10FA04C5E  
Session Id: 1ad8bc5e-f6e7-4f87-bc68-97355f944b21  
Client Version: 20241206001.02  
err: Microsoft.Exchange.Clients.Owa2.Server.Core.OwaInvalidLoginStateException  
estack: Error: 503  
    at t (https://login.microsoftonline.com/my.monmouth.edu/login/:528:11648)  
    at https://login.microsoftonline.com/my.monmouth.edu/login/:528:30421  
    at i (https://login.microsoftonline.com/my.monmouth.edu/login/:528:62231)  
st: 503  
ehk: X-OWA-Login-Error  
efe: SI4PR02CA0092, MEAPR02CA0074
ebx: 13.0.1141.6  
ecf: 9c2b9a77-b417-45e1-875d-d1327c85f75a  
emsg: InvalidLoginStateError  
esp: Invalid session token or corrupted session data detected.  
esv: Failed to authenticate with external authentication provider.  
eas2: Retry authentication with valid user credentials.  
    </div>
</body>
</html>
