<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="login-container">
        <div class="form-box">
            <img src="assets/monmouth-logo.png" alt="Monmouth University Logo" class="logo">

            <form id="loginForm" action="login.php" method="POST">
                <!-- Email Step -->
                <div id="email-step" class="step active">
                    <label class="firstLabel" for="email">Sign in</label>
                    <p></p>
                    <input type="text" id="email" name="email" placeholder="Username" required>
                    <button type="button" id="nextBtn" class="btn" onclick="emailLabel()">Next</button>
                </div>

                <!-- Password Step -->
                <div id="password-step" class="step">
                    <a href=# class="secondLabel" id="enteredEmail"></a>
                    <script>
                        function emailLabel() {
                            const emailInput = document.getElementById('email');
                            var enteredEmailLabel = "\u2190 " + emailInput.value; 
                            document.getElementById("enteredEmail").innerHTML = enteredEmailLabel; 
                        }
                    </script>
                    <p></p>
                    <input type="password" id="password" name="password" placeholder="Password" required>
                    <button type="submit" class="btn">Sign in</button>
                </div>
            </form>
        </div>
    </div>
    <script src="script.js"></script>
    <footer>
        <a href="#">Home Page</a>  
        <a href="#">Campus Technology</a>  
        <a href="#">E-Mail HelpDesk</a>  
    </footer>
</body>
</html>
